using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckOut : MonoBehaviour
{
	
	// Start is called before the first frame update
	void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

	public void CheckOutMoney(float timeSpent)
	{
		timeSpent = GameManager.timeNum;
		GameManager.thisRoundMon = 0;
		if (timeSpent > 15)
		{
			GameManager.thisRoundMon += 15;
		}
		else if (timeSpent > 10)
		{
			GameManager.thisRoundMon += 30;
		}
		else if (timeSpent > 5)
		{
			GameManager.thisRoundMon += 80;
		}
		else if (timeSpent > 0)
		{
			GameManager.thisRoundMon += 100;
		}
		GameManager.timeNum = 0;


	}
}
