using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PaintPizza : MonoBehaviour
{

    public KeyCode mouseLeft;
    public static string toolType;
    
    public static Transform thingsToPut;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector2 mousePositions = new Vector2(Input.mousePosition.x, Input.mousePosition.y); //get mouse position
        Vector2 objPosition = Camera.main.ScreenToWorldPoint(mousePositions); //adjust mouse position base on camera

        if (Input.GetKey(mouseLeft) && toolType == "addStuff") //a single click 
        {
            Instantiate(thingsToPut, objPosition, thingsToPut.rotation);
        }

    }
}
